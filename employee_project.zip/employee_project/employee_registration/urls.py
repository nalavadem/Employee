# employee_registration/urls.py
from django.urls import path
from . import views
from .views import authView, home

urlpatterns = [
    path("", home, name="home"),
    path('register/', views.register_employee, name='register_employee'),
    path('employee_list/', views.employee_list, name='employee_list'),

    path("signup/", authView, name="authView"),

]

