from django.contrib import admin

# Register your models here.
# employee_registration/admin.py
from django.contrib import admin
from .models import Employee

admin.site.register(Employee)
